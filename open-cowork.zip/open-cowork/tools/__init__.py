"""Open Co-Work tools. Every module here is auto-loaded by ``tools.registry``."""
